﻿namespace DavidTielke.PMA.UI.ConsoleClient;

internal interface IPersonDisplayCommand
{
    void DisplayAllAdults();
    void DisplayAllChildren();
}