﻿using System.Security.AccessControl;
using DavidTielke.PMA.Data.DataStoring;
using DavidTielke.PMA.Data.FileStoring;
using DavidTielke.PMA.Logic.PersonManagement;
using Mappings;
using Microsoft.Extensions.DependencyInjection;

namespace DavidTielke.PMA.UI.ConsoleClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var serviceCollection = new ServiceCollectionFactory().Create();

            serviceCollection.AddTransient<IPersonDisplayCommand, PersonDisplayCommand>();
            serviceCollection.AddTransient<App>();

            var builder = serviceCollection.BuildServiceProvider();

            var app = builder.GetRequiredService<App>();
            app.Run();
        }
    }
}
